INSTALL-ONLY DOWNLOAD
The game files are identical to the full first-edition package.
The large source CSV and converter tools are available in the full package,
not in this smaller download. Reports are retained.

CM 01/02 WOMEN 2025 - FIRST TEST EDITION (v0.1 alpha)
==================================================

This is a database and executable overlay for a complete Championship Manager
01/02 version 3.9.68 installation. It is not a complete game installation.

STATUS
------
The binary, source-data and reference checks pass. The converter has passed its
unit tests. No Windows new-game, save/reload or season-rollover test has been run.
Use a separate copy of your game installation for this first test edition.

CONTENTS
--------
- 45,824 imported player records from your FM26 women's CSV.
- 2,673 source clubs mapped into the existing world or added as new clubs.
- 36 Arsenal player records, including Leah Williamson, Alessia Russo, Beth Mead,
  Kim Little, Katie McCabe, Chloe Kelly and Manuela Zinsberger.
- Rebuilt staff, attributes, preferences and name tables; corrected index offsets.
- A 2025 start-year executable based only on the exact cm0102.exe you supplied.
- Rebuilt squad links; legacy staff and player-history links removed.
- Female-derived name pools for regeneration testing, not a new gender engine.
- Reports covering exclusions, names, clubs, nationalities, contracts and repairs.
- Conversion reports; the complete source CSV is in the full package.

INSTALL ON A COPY OF YOUR GAME
------------------------------
1. Close CM 01/02. Copy your complete working 3.9.68 installation to a separate
   folder, for example CM0102-Women-Test. Keep your normal installation intact.
2. Keep a backup of that copy's cm0102.exe and Data folder.
3. Extract this ZIP into a temporary folder. Copy this package's cm0102.exe into
   the root of CM0102-Women-Test. Copy every file inside this package's Data
   folder into the existing Data folder there, replacing those files. Retain the
   rest of the complete installation: language, pictures, configuration and other
   game assets are not supplied by this overlay.
4. The empty player_setup.cfg supplied here intentionally disables old men's
   loans, future transfers and injury setup from the previous database.
5. Run the executable from CM0102-Women-Test, not a shortcut to another install.
6. Select Maximum database size, and START A NEW GAME. Existing saved careers
   contain their own old database and will not become this edition.
7. For the first smoke test, select England and manage Arsenal. Confirm the game
   date is in 2025. Leah Williamson should have a 29 March 1997 birthday and
   Alessia Russo an 8 February 1999 birthday. Check the squad and play friendlies.
8. Save, exit the game completely, and reload. Then test league matches, transfers,
   the June/July season rollover, and newly generated players' names. Repeat with
   the five target nations selected after the small test succeeds.

DATE PATCH: DO NOT APPLY ANOTHER START-YEAR CHANGE
-----------------------------------------------
This package uses Nick's older data-date strategy: actual dates are stored in
the DAT files, and the executable's year constants are changed to 2025. The
datecalc loader hook which would add 24 years to birth dates is not installed.
Do not enable a second date-shifting patch on top of this edition. Its output
hash and every executable write are recorded in manifest.json and Reports.

FIRST-EDITION COMPETITION FORMATS
-------------------------------
The game keeps its original competition lookup names and legacy rules. The five
target top divisions are filled with source women's clubs but retain these sizes:

    England: 20    France: 18    Germany: 18    Italy: 18    Spain: 20

They are seeded mainly by source club reputation. They are NOT the real 2025/26
women's division memberships, league sizes, qualification rules or calendars.
Other legacy clubs and lower divisions remain in the world; some lack supplied
squads and may receive generated players. Generated-player behavior is untested.
Competition and country labels, many club names, text pronouns, venues and
financial behavior still come from the original game/base database.

WHAT IS APPROXIMATED OR OMITTED
------------------------------
- 470 of the 46,294 source players are not imported. There are 366 with unsupported
  primary nations, 42 with unsupported club nations, and 62 reserve-overflow
  players at clubs exceeding CM's 50-player squad array. Every exclusion is listed
  in Reports/excluded-players.csv. The source CSV in the full package includes them all.
- Nation mappings are specific to your source snapshot and manually interpreted
  from the player/club data. The FM save's nation table was not available to verify
  them independently. Countries absent from CM were not replaced by unrelated ones.
- FM and CM club IDs are different. Some women-to-parent club aliases reuse the
  legacy parent identity, labels, colours and grounds. New clubs have neutral kit,
  finance and ground placeholders, including capital-city ground locations.
- Club squad overflow prioritizes source senior-team slots, then current ability,
  potential ability and stable source ID. No overflow player was silently made a
  free agent. The source's clubless players remain unassigned.
- Loans are simplified to current club membership. The source CSV preserves parent
  registration, loan dates and other details for a later edition.
- Wages and transfer values are set to zero for game initialization because the
  source money units were not established. These are not accurate women's finances.
- Missing, future or expired contract dates use explicit gameplay placeholders;
  Reports/contract-placeholders.csv identifies affected players. Do not interpret
  those dates as verified real-world agreements.
- Unicode names unrepresentable in the legacy encoding are transliterated, and
  overly long names are shortened. Original values are in the source CSV and the
  name-conversion report. Only one mapped secondary nationality is retained.
- FM-only attributes, height and other non-equivalent fields remain in the source
  CSV. Most attributes have direct equivalents; positions use CM's role/side model.
- There is no real manager/coaching-staff import. Old staff pointers are cleared;
  NPC creation is left to the game and needs a new-game test. Legacy referees keep
  their attributes with female-derived composite names, not real referee identities.
- Histories are cleared rather than presenting men's winners or careers as women's
  history. Unsupported legacy negative references are normalized and logged.
- The CSV has no sex/gender field; the women's subset is the selection you supplied.
  CM's underlying gender-specific language and behavior have not been rewritten.

TEST RESULTS AND REPORTS
------------------------
Reports/validation.json distinguishes the checks that passed from gameplay tests
that have not run. The validator checks every imported birthday, CA/PA pair,
1,832,960 mapped attribute values, all club/squad and name references, national
club IDs, stadium/city/rival references, nation counters and executable write scope.

manifest.json hashes the installation files; FILES.sha256 covers the package.
Reports/player-crosswalk.csv and club-crosswalk.csv track source-to-CM identity.
Reports/leagues.json lists seeded divisions and their membership.
The full package contains the build tools, schemas and configuration for review/rebuild.
Rebuilding requires the ORIGINAL uploaded DAT files and executable, not these
already-converted output files. The complete source CSV is in Reports in the full package.

ROLLBACK
--------
Close the game and discard the test installation, or restore the cm0102.exe and
Data folder you backed up before installing. Keep any test saved careers separate;
restoring the old DAT files does not convert test careers back to the old world.

IF THE FIRST TEST FAILS
----------------------
Keep the test save if one was created. Record the selected nations/divisions,
the exact error text (including any .cpp name and line), the in-game date, and
whether it happened on new-game creation, match play, saving/reloading or rollover.
These details are needed to distinguish a loader problem from competition setup.
