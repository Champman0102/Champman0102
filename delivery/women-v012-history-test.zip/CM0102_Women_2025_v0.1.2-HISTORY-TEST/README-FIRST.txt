CM 01/02 WOMEN 2025 - v0.1.2 HISTORY TEST
=======================================

This test build addresses the crash location reported in Windows Event Viewer.
Windows new-game success is still UNVERIFIED. Test in a separate game copy.

WHAT THE CRASH LOG REVEALED
- Exception 0xc0000005 at module offset 0x126c95 maps to VA 0x526c95.
- That instruction reads the competition-history table during club filtering.
- v0.1 clears historical results. With zero records and a NULL runtime pointer,
  the original loop calculates an invalid end address and reads address 0xA.
- Executing the original x86 code reproduces the same fault instruction under
  that explicit empty-table condition. The adjacent staff-history loop has the
  same defect. No crash dump/register capture was available from your PC, so
  this establishes the matching code defect, not every detail of your crash.

CHANGES
- Adds guards to those two native loops so empty histories are skipped.
  Only 31 bytes of loop setup are replaced, in place. No new loader or injected
  code section is added. Positive-length traversal is regression-tested.
- Includes the corrected player reputations (DAT 0..200) from the staff test.
- Includes 20,326 GENERATED PLACEHOLDER support staff with female-derived name
  pairs and generic attributes. These are not real 2025 managers/coaches.
- Retains all 45,824 imported player identities, birthdays, CA/PA and playing
  attributes. Historical results remain empty; no fabricated winners are added.
- Retains the existing 2025 date changes, legacy league structures and formats.

INSTALL AND TEST
1. Make a separate copy of your complete CM 01/02 3.9.68 installation.
2. Merge this package's Data folder into that copy's existing Data folder,
   replacing matching files. Copy its cm0102.exe into the game root as well.
   Keep original language files and all other game assets. Do not copy staff.dat
   by itself: the index, names, club links and staff data must match.
3. Start a NEW game, select England, choose Maximum database size and Continue.
   Existing saved careers do not adopt these database changes.
4. If it crashes, run Get-Crash-Log.cmd and send the latest exception code and
   fault offset. A different offset is useful evidence for the next defect.
   The helper reads local logs and file details; it changes no game files and
   sends nothing automatically. Check the event time matches your latest test.

VERIFICATION AND LIMITS
31 parser/conversion/native regression tests pass in the build workspace.
The original empty-history loops reproduce faults at 0x526c95 and 0x526d19;
patched loops accept NULL and allocated empty tables. Populated traversal matches
the original, including club ID zero and the last record. Installation files
are checked against the manifest and the ZIP's hashes/CRCs are verified.

These isolated x86 and structural checks are not a full Windows game test.
No Windows new-game, save/reload or season-rollover test has run here.
Original full installation assets are required and are not included.
League sizes/rules/names remain legacy CM formats, rather than authentic women's
formats. Some clubs, finances, grounds and contracts remain placeholders.
470 source players were excluded for unsupported nation mapping or squad limits.
Loans are simplified. Pronouns, graphics and the underlying gender engine have
not been rewritten. The user supplied the women-only player selection.

Reports/generated-staff.csv lists the synthetic staff and their roles.
Reports/reputation-correction.csv lists the reputation unit corrections.
Reports/history-guard-writes.json lists both exact executable changes.
Reports/validation.json distinguishes native/structural checks from game tests.
