@echo off
setlocal
set "CM_DIAG_OUTPUT_DIR=%~dp0"
set "CM_DIAG_GAME_DIR=%~dp0"
echo Enter your game installation folder, or press Enter to use this folder.
set /p "CM_DIAG_GAME_DIR=Game folder: "
powershell.exe -NoProfile -Command "$ErrorActionPreference='Stop'; $game=$env:CM_DIAG_GAME_DIR.Trim([char]34); $log=Join-Path $env:CM_DIAG_OUTPUT_DIR 'cm0102-crash.txt'; $lines=@('CM0102 crash diagnostic','Game folder: '+$game); foreach($rel in @('cm0102.exe','Data\eng.lng','Data\index.dat','Data\staff.dat')) { $p=Join-Path $game $rel; $exists=Test-Path -LiteralPath $p -PathType Leaf; $lines+=($rel+' exists: '+$exists); if($exists) { $lines+=('  bytes: '+(Get-Item -LiteralPath $p).Length); if($rel -eq 'cm0102.exe') { $lines+=('  SHA256: '+(Get-FileHash -LiteralPath $p -Algorithm SHA256).Hash) } } }; $lines | Out-File -LiteralPath $log -Encoding utf8; $events=@(Get-WinEvent -FilterHashtable @{LogName='Application';Id=1000,1001;StartTime=(Get-Date).AddDays(-2)} -MaxEvents 400 -ErrorAction SilentlyContinue | Where-Object {$_.Message -match 'cm0102[.]exe'} | Select-Object -First 3); if($events.Count -gt 0) { $events | Format-List TimeCreated,Id,Message | Out-File -LiteralPath $log -Encoding utf8 -Append } else { 'No recent matching Windows crash event was found. The game may have exited without a Windows crash event.' | Out-File -LiteralPath $log -Encoding utf8 -Append }; Write-Host ('Saved: '+$log)"
if errorlevel 1 echo The log helper failed. Please send the error shown above.
pause
endlocal
